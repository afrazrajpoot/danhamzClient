import React from 'react'
import Loader from '../../pages/Reports/Loader'

const Loading = () => {
  return (
   <Loader />
  )
}

export default Loading